### Repo for 2019guess

#### How to start server: 
1. Open the terminal
2. `cd` into the folder where game.js is
3. Start game by typing `node game` and enter
4. The terminal should now say `server running 8080`
